﻿using UnityEngine;
using System.Collections;

public class BasicMovement : MonoBehaviour {


	public float movespeed = 10f;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{	

		Vector3 moveDir = Vector3.zero;
		moveDir.x = Input.GetAxis ("Horizontal");
		moveDir.z = Input.GetAxis ("Vertical");
		transform.position += moveDir * movespeed * Time.deltaTime;
	}
}
